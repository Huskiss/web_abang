function user_register() {
    location.href = '/users/signup'
}