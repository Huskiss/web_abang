from django.apps import AppConfig


class CalendarsConfig(AppConfig):
    name = 'calendars'
