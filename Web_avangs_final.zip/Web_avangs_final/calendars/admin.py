from django.contrib import admin
from calendars.models import Calendar

admin.site.register(Calendar)
