from django.apps import AppConfig


class BookmarksConfig(AppConfig):
    name = 'bookmarks'
