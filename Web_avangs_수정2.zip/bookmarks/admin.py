from django.contrib import admin
from bookmarks.models import Post

admin.site.register(Post)
