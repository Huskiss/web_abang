from django.contrib import admin
from maps.models import Cal, Book

admin.site.register(Cal)
admin.site.register(Book)
